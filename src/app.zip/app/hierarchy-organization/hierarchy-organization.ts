export class HierarchyOrganization {
    id !: number;
    orgName! : string;
    location! : string;
    owner! : string;


}
    

