import { Component } from '@angular/core';

@Component({
  selector: 'app-display-timesheet',
  templateUrl: './display-timesheet.component.html',
  styleUrls: ['./display-timesheet.component.css'],

})
export class DisplayTimesheetComponent {

}
