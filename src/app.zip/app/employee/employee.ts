export interface Employee {
        Name : string;
        location : string;
        gender : string;
        designation : string;
        category : string;
        projectId : number;
        leadId : number;
        organizationId : number;
        clientCounterpartId : number;
        band : number;
}
