export class organization {
    id!:number;
    orgName! :string;
    location!:string;
    owner!:string;
    ownerEmpId! :string;
    parentOrg! :number
}
