import { Component } from '@angular/core';

@Component({
  selector: 'app-slab-charges',
  templateUrl: './slab-charges.component.html',
  styleUrls: ['./slab-charges.component.css']
})
export class SlabChargesComponent {

}
