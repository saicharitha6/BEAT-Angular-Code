export class Hierarchy {
   id !: number;
   name ! :string;
   designation ! :string;
   orgName !: string
}

