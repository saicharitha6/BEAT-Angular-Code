export interface EmployeeDetails {
    id: number;
    name :string;
    designation :string;
    organization :string
}
